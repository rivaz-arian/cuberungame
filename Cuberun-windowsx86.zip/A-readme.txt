read this text before installing the application

------------------------------------------------
1.requires 64bit Operating System
 
2.works only on Windows 7,8,8.1,10,11 (not tested on Windows XP)

3.requires at leat 15MB of space (mostly your PC has more that this space)

-------------------------------------------------FOR PROFESSIONAL PEOPLE ONLY
1.if you want you can install the app on another folder ( the default installing folder is at "program files x86)

----------------------------
leave any ideas at my github page!
"https://github.com/rivaz-arian"

